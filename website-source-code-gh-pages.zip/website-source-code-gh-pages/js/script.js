

    window.silex = window.silex || {}
    window.silex.data = {"site":{"width":1306},"pages":[{"id":"page-home","displayName":"Home","link":{"linkType":"LinkTypePage","href":"#!page-home"},"canDelete":true,"canProperties":true,"canMove":true,"canRename":true,"opened":false},{"id":"page-github","displayName":"Github","link":{"linkType":"LinkTypePage","href":"#!page-github"},"canDelete":true,"canRename":true,"canMove":true,"canProperties":true,"opened":false}]}